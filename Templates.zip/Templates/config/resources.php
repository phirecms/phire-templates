<?php

return [
    'templates' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];