/**
 * Templates Module Scripts for Phire CMS 2
 */
