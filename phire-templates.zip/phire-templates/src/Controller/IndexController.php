<?php

namespace Phire\Templates\Controller;

use Phire\Templates\Model;
use Phire\Templates\Form;
use Phire\Templates\Table;
use Phire\Controller\AbstractController;

class IndexController extends AbstractController
{

    /**
     * Index action method
     *
     * @return void
     */
    public function index()
    {
        $this->prepareView('templates/index.phtml');
        $templates = new Model\Template();

        $this->view->title     = 'Templates';
        $this->view->templates = $templates->getAll($this->request->getQuery('sort'));

        $this->send();
    }

    /**
     * Add action method
     *
     * @return void
     */
    public function add()
    {
        $this->prepareView('templates/add.phtml');
        $this->view->title = 'Templates : Add';

        $fields = $this->application->config()['forms']['Phire\Templates\Form\Template'];

        $templates = Table\Templates::findAll();
        foreach ($templates->rows() as $tmpl) {
            $fields[0]['template_parent_id']['value'][$tmpl->id] = $tmpl->name;
        }

        $this->view->form = new Form\Template($fields);

        if ($this->request->isPost()) {
            $this->view->form->addFilter('htmlentities', [ENT_QUOTES, 'UTF-8'])
                 ->setFieldValues($this->request->getPost());

            if ($this->view->form->isValid()) {
                $this->view->form->clearFilters()
                     ->addFilter('html_entity_decode', [ENT_QUOTES, 'UTF-8'])
                     ->filter();
                $template = new Model\Template();
                $template->save($this->view->form->getFields());
                $this->view->id = $template->id;
                $this->redirect(BASE_PATH . APP_URI . '/templates/edit/'. $template->id . '?saved=' . time());
            }
        }

        $this->send();
    }

    /**
     * Edit action method
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        $template = new Model\Template();
        $template->getById($id);

        if (!isset($template->id)) {
            $this->redirect(BASE_PATH . APP_URI . '/templates');
        }

        $this->prepareView('templates/edit.phtml');
        $this->view->title         = 'Templates';
        $this->view->template_name = $template->name;

        $fields = $this->application->config()['forms']['Phire\Templates\Form\Template'];

        $templates = Table\Templates::findAll();
        foreach ($templates->rows() as $tmpl) {
            if ($tmpl->id != $id) {
                $fields[0]['template_parent_id']['value'][$tmpl->id] = $tmpl->name;
            }
        }

        if (null !== $template->history) {
            $history = json_decode($template->history, true);
            $fields[0]['template_history'] = [
                'type'  => 'select',
                'label' => 'Select Revision',
                'value' => [
                    '0' => '(Current)'
                ],
                'attributes' => [
                    'onchange' => 'phire.changeTemplateHistory(this);'
                ]
            ];
            krsort($history);
            foreach ($history as $timestamp => $value) {
                $fields[0]['template_history']['value'][$timestamp] = date('M j, Y H:i:s', $timestamp);
            }
        }

        $fields[1]['name']['attributes']['onkeyup'] = 'phire.changeTitle(this.value);';

        $this->view->form = new Form\Template($fields);
        $this->view->form->addFilter('htmlentities', [ENT_QUOTES, 'UTF-8'])
             ->setFieldValues($template->toArray());

        if ($this->request->isPost()) {
            $this->view->form->setFieldValues($this->request->getPost());

            if ($this->view->form->isValid()) {
                $this->view->form->clearFilters()
                     ->addFilter('html_entity_decode', [ENT_QUOTES, 'UTF-8'])
                     ->filter();
                $template = new Model\Template();

                $template->update($this->view->form->getFields(), $this->application->module('phire-templates')->config()['history']);
                $this->view->id = $template->id;
                $this->redirect(BASE_PATH . APP_URI . '/templates/edit/'. $template->id . '?saved=' . time());
            }
        }

        $this->send();
    }

    /**
     * Copy action method
     *
     * @param  int $id
     * @return void
     */
    public function copy($id)
    {
        $template = new Model\Template();
        $template->getById($id);

        if (!isset($template->id)) {
            $this->redirect(BASE_PATH . APP_URI . '/$templates');
        }

        $template->copy($this->application->modules()->isRegistered('phire-fields'));
        $this->redirect(BASE_PATH . APP_URI . '/templates?saved=' . time());
    }

    /**
     * Json action method
     *
     * @param  int $id
     * @param  int $marked
     * @return void
     */
    public function json($id, $marked)
    {
        $json = [];

        $template = Table\Templates::findById($id);
        if (isset($template->id) && (null !== $template->history)) {
            $history = json_decode($template->history, true);
            if (isset($history[$marked])) {
                $json['value'] = $history[$marked];
            }
        }

        $this->response->setBody(json_encode($json, JSON_PRETTY_PRINT));
        $this->send(200, ['Content-Type' => 'application/json']);
    }

    /**
     * Remove action method
     *
     * @return void
     */
    public function remove()
    {
        if ($this->request->isPost()) {
            $template = new Model\Template();
            $template->remove($this->request->getPost());
        }
        $this->redirect(BASE_PATH . APP_URI . '/templates?removed=' . time());
    }

    /**
     * Prepare view
     *
     * @param  string $template
     * @return void
     */
    protected function prepareView($template)
    {
        $this->viewPath = __DIR__ . '/../../view';
        parent::prepareView($template);
    }

}
