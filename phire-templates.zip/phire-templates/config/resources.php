<?php

return [
    'templates' => [
        'index',
        'add',
        'edit',
        'copy',
        'upload',
        'remove'
    ]
];