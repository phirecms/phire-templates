<?php

return [
    'templates' => [
        'index',
        'add',
        'edit',
        'copy',
        'remove'
    ]
];